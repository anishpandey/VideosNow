//
//  VocSdkVersion.h
//
//  Copyright (c) 2015,2016 Akamai Inc. All rights reserved.
//

#define VOCSDK_MAJOR			18
#define VOCSDK_MINOR			22
#define VOCSDK_BUILD			9999
#define VOCSDK_VERSION_STRING	"18.22.9999"
