//
//  VocSdkVersion.h
//
//  Copyright (c) 2015,2016 Akamai Inc. All rights reserved.
//

#define VOCSDK_MAJOR			18
#define VOCSDK_MINOR			31
#define VOCSDK_BUILD			575
#define VOCSDK_VERSION_STRING	"18.31.575"
